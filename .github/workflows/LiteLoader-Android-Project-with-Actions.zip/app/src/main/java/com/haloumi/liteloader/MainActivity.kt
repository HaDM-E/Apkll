package com.haloumi.liteloader

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Context
import android.os.Build

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 10, 19)
    private val panel = Color.rgb(27, 22, 39)
    private val purple = Color.rgb(183, 140, 255)
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(24), dp(20), dp(20))
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)

        val title = TextView(this).apply {
            text = "LITE LOADER"
            textSize = 27f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        }
        content.addView(title)

        val sub = TextView(this).apply {
            text = "ROOT EDITION  •  VERSION 1.0"
            textSize = 11f
            setTextColor(purple)
            setPadding(0, dp(5), 0, dp(18))
        }
        content.addView(sub)

        status = TextView(this).apply {
            text = "Checking root status..."
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel)
        }
        content.addView(status)
        status.text = if (hasRoot()) "● ROOT ACCESS DETECTED" else "● ROOT NOT DETECTED"
        status.setTextColor(if (hasRoot()) Color.rgb(105, 230, 160) else Color.rgb(255, 190, 90))

        section(content, "PERFORMANCE")
        infoCard(content, "FPS Monitor", "Display and record local device refresh information.")
        infoCard(content, "Device Status", "Android ${Build.VERSION.RELEASE}  •  SDK ${Build.VERSION.SDK_INT}")
        infoCard(content, "Game Profile", "PUBG Mobile Lite profile label only; no game modification.")

        section(content, "CUSTOMIZATION")
        addSwitch(content, "Custom Crosshair", "Preview-only crosshair setting")
        addSwitch(content, "Aim Training Simulator", "Standalone practice toggle; does not control the game")
        addSwitch(content, "ESP Simulation", "Demo overlay state inside this app only")
        addSwitch(content, "Aim Assist Simulation", "Training/demo switch only")

        val note = TextView(this).apply {
            text = "Notice: This build does not inject code into PUBG, read game memory, reveal player locations, or automate aiming."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(18), 0, dp(10))
        }
        content.addView(note)

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = TextView(this).apply {
            text = "LITE LOADER  •  BUILT FOR ANDROID"
            gravity = Gravity.CENTER
            textSize = 10f
            setTextColor(purple)
            setPadding(0, dp(12), 0, 0)
        }
        root.addView(footer)
        setContentView(root)
    }

    private fun section(parent: LinearLayout, label: String) {
        val t = TextView(this).apply {
            text = label
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(purple)
            setPadding(0, dp(20), 0, dp(9))
        }
        parent.addView(t)
    }

    private fun infoCard(parent: LinearLayout, heading: String, detail: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(panel)
            setPadding(dp(14), dp(13), dp(14), dp(13))
        }
        val h = TextView(this).apply {
            text = heading
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        val d = TextView(this).apply {
            text = detail
            textSize = 11f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(5), 0, 0)
        }
        box.addView(h); box.addView(d)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(9)
        parent.addView(box, lp)
    }

    private fun addSwitch(parent: LinearLayout, label: String, detail: String) {
        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(panel)
            setPadding(dp(12), dp(8), dp(8), dp(8))
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val name = TextView(this).apply {
            text = label
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val desc = TextView(this).apply {
            text = detail
            textSize = 10f
            setTextColor(Color.LTGRAY)
        }
        texts.addView(name); texts.addView(desc)
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        val toggle = Switch(this).apply {
            buttonTintList = android.content.res.ColorStateList.valueOf(purple)
            isChecked = prefs.getBoolean(label, false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(label, checked).apply()
            }
        }
        row.addView(toggle)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(8)
        parent.addView(row, lp)
    }

    private fun hasRoot(): Boolean {
        val paths = arrayOf(
            "/system/bin/su", "/system/xbin/su",
            "/sbin/su", "/system/app/Superuser.apk",
            "/data/adb/magisk"
        )
        return paths.any { java.io.File(it).exists() }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
