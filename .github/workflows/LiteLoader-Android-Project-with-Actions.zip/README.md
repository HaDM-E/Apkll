# Lite Loader

Starter Android project (Kotlin) for Android 11+.

## Build an APK from your phone with GitHub Actions

1. Create a new GitHub repository.
2. Upload the **contents** of this folder to the repository root (including the hidden `.github` folder).
3. Open the repository's **Actions** tab.
4. Select **Build Lite Loader APK**.
5. Tap **Run workflow** (or wait for the automatic build after pushing to `main`).
6. When the run finishes, open it and download the artifact named `LiteLoader-debug-apk`.
7. Extract the artifact ZIP; it contains `app-debug.apk`.

This starter build provides a local settings interface and demo-only training/simulation toggles.
It does not inject into PUBG, inspect game memory, reveal opponents, or automate aiming.
